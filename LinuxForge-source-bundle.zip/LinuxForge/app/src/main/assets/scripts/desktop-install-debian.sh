#!/bin/sh
set -eu
case "${1:-xfce}" in
 xfce) apt-get update && apt-get install -y xfce4 xfce4-goodies dbus-x11 ;;
 lxqt) apt-get update && apt-get install -y lxqt qterminal dbus-x11 ;;
 kde) apt-get update && apt-get install -y kde-plasma-desktop konsole dbus-x11 ;;
 *) echo 'Usage: desktop-install-debian.sh xfce|lxqt|kde' >&2; exit 2;;
esac
