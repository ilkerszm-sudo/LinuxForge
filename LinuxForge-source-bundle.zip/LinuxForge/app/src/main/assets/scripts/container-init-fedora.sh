#!/bin/sh
set -eu
dnf -y install ca-certificates curl wget procps-ng iproute nano sudo
