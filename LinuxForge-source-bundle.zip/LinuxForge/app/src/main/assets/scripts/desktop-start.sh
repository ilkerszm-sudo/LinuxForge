#!/bin/sh
set -eu
export DISPLAY="${DISPLAY:-:0}"
export PULSE_SERVER="${PULSE_SERVER:-127.0.0.1}"
case "${1:-xfce}" in
 xfce) exec dbus-launch --exit-with-session startxfce4 ;;
 lxqt) exec dbus-launch --exit-with-session startlxqt ;;
 kde) exec dbus-launch --exit-with-session startplasma-x11 ;;
 *) echo 'Usage: desktop-start.sh xfce|lxqt|kde' >&2; exit 2;;
esac
