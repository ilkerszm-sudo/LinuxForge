#!/bin/sh
set -eu
case "${1:-debian}" in
 debian|ubuntu) apt-get update && apt-get upgrade -y ;;
 fedora) dnf -y upgrade ;;
 freebsd) pkg update -f && pkg upgrade -y ;;
 *) echo 'Unknown distro family' >&2; exit 2;;
esac
