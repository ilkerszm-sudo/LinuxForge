#!/bin/sh
# Helper notes for a Linux container; obtain official archives and verify checksums.
set -eu
: "${ANDROID_SDK_ROOT:=$HOME/Android/Sdk}"
mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
echo "Install official Android command-line tools into $ANDROID_SDK_ROOT/cmdline-tools/latest."
echo "Then run sdkmanager --sdk_root=$ANDROID_SDK_ROOT 'platform-tools' 'platforms;android-35' 'build-tools;35.0.0' 'ndk;27.2.12479018'"
echo "Use a JDK 17 distribution and accept SDK licenses before building."
