package dev.linuxforge.engine

import android.content.Context
import java.io.File

class ContainerRegistry(context:Context) {
    private val dir=File(context.filesDir,"containers")
    fun list():List<String> = dir.listFiles()?.filter{it.isDirectory}?.map{it.name} ?: emptyList()
}
