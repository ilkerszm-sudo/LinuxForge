package dev.linuxforge.terminal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
data class ShellResult(val exitCode:Int,val output:String)
class CommandRunner {
 suspend fun run(args:List<String>,cwd:File?=null,env:Map<String,String> = emptyMap()):ShellResult=withContext(Dispatchers.IO){
  require(args.isNotEmpty());runCatching{val b=ProcessBuilder(args).redirectErrorStream(true);cwd?.let{b.directory(it)};b.environment().putAll(env);val p=b.start();val out=p.inputStream.bufferedReader().use{it.readText()};ShellResult(p.waitFor(),out)}.getOrElse{ShellResult(-1,it.message?:"Process failed")}
 }
}
