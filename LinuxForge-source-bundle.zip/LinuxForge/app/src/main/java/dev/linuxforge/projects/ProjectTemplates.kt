package dev.linuxforge.projects
object ProjectTemplates {
 fun bootstrap(distro:String):String = "Android CLI toolchain setup (manual bootstrap):\nInstall JDK, curl, unzip, then download Android command-line tools from developer.android.com.\nConfigure ANDROID_HOME, install platform-tools, platforms;android-35, build-tools;35.0.0, ndk and Kotlin/Gradle.\nContainer distro: $distro. Verify license acceptance and architecture compatibility."
 fun template(kind:String):String = when(kind){"Android app"->"Template plan: app/build.gradle.kts, Android manifest, MainActivity, Gradle wrapper, SDK requirements. Create in workspace once SDK is installed.";else->"Kotlin console template: build.gradle.kts, settings.gradle.kts, src/main/kotlin/Main.kt and Gradle wrapper. Generate in workspace."}
}
