package dev.linuxforge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.linuxforge.engine.*
import dev.linuxforge.terminal.CommandRunner
import dev.linuxforge.packages.PackageCommands
import dev.linuxforge.desktop.DesktopProfiles
import dev.linuxforge.projects.ProjectTemplates
import dev.linuxforge.files.AppFileOps

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        setContent { LinuxForgeUI(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun LinuxForgeUI(activity: ComponentActivity) {
    val tabs = listOf("Containers","Desktop","Projects","Packages","Updates","AI","VMs","Files","Terminal","Settings")
    var tab by remember { mutableStateOf("Containers") }
    var output by remember { mutableStateOf("LinuxForge ready. Select an action.") }
    var distro by remember { mutableStateOf("Debian") }
    var containerName by remember { mutableStateOf("debian") }
    var desktop by remember { mutableStateOf("XFCE") }
    var command by remember { mutableStateOf("pwd && ls") }
    var aiPrompt by remember { mutableStateOf("") }
    var provider by remember { mutableStateOf("OpenAI") }
    val engine = remember { ContainerEngine(activity) }
    val registry = remember { ContainerRegistry(activity) }
    val runner = remember { CommandRunner(activity) }
    val rootfs = remember { RootfsManager(activity) }
    val scroll = rememberScrollState()
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text("LinuxForge") }) }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                ScrollableTabRow(selectedTabIndex = tabs.indexOf(tab), edgePadding = 8.dp) {
                    tabs.forEach { t -> Tab(selected = tab == t, onClick = { tab = t }, text = { Text(t) }) }
                }
                Column(Modifier.weight(1f).verticalScroll(scroll).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    when(tab) {
                        "Containers" -> {
                            Text("Container manager", style = MaterialTheme.typography.headlineSmall)
                            OutlinedTextField(containerName, {containerName=it}, label={Text("Container name")}, modifier=Modifier.fillMaxWidth())
                            Dropdown("Distribution", distro, listOf("Debian","Ubuntu","Fedora","FreeBSD (experimental)")){distro=it}
                            Button(onClick={ output= "Preparing $distro root filesystem…"; rootfs.install(containerName,distro){ output=it } }, modifier=Modifier.fillMaxWidth()) { Text("Download / install rootfs") }
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Button(onClick={output=engine.start(containerName)}){Text("Start")}; Button(onClick={output=engine.stop(containerName)}){Text("Stop")}; Button(onClick={output=engine.remove(containerName)}){Text("Delete") } }
                            Button(onClick={output=registry.list().joinToString("\n").ifBlank{"No registered containers."}){Text("List containers")}
                        }
                        "Desktop" -> {
                            Text("Linux desktop", style=MaterialTheme.typography.headlineSmall)
                            Dropdown("Desktop environment",desktop,listOf("XFCE","LXQt","KDE Plasma")){desktop=it}
                            Text("Requires a compatible X server such as Termux:X11 installed separately.")
                            Button(onClick={output=DesktopProfiles.installCommand(distro,desktop)}){Text("Show installation commands")}
                            Button(onClick={output=engine.desktopCommand(containerName,desktop)}){Text("Launch desktop")}
                        }
                        "Projects" -> {
                            Text("Android / Kotlin project tools", style=MaterialTheme.typography.headlineSmall)
                            Text("Templates and setup commands for Android SDK, NDK, JDK, Kotlin and Gradle.")
                            Button(onClick={output=ProjectTemplates.bootstrap(distro)}){Text("Show toolchain setup")}
                            Button(onClick={output=ProjectTemplates.template("Kotlin console")}){Text("Create Kotlin template (instructions)")}
                            Button(onClick={output=ProjectTemplates.template("Android app")}){Text("Create Android template (instructions)")}
                        }
                        "Packages" -> {
                            Text("Graphical package actions", style=MaterialTheme.typography.headlineSmall)
                            Text("Package command helpers for apt, dnf and pkg.")
                            Button(onClick={output=PackageCommands.refresh(distro)}){Text("Refresh package indexes")}
                            OutlinedTextField(command,{command=it},label={Text("Package name or query")},modifier=Modifier.fillMaxWidth())
                            Button(onClick={output=PackageCommands.search(distro,command)}){Text("Search")}
                            Button(onClick={output=PackageCommands.install(distro,command)}){Text("Install")}
                            Button(onClick={output=PackageCommands.remove(distro,command)}){Text("Uninstall")}
                        }
                        "Updates" -> {
                            Text("System updates",style=MaterialTheme.typography.headlineSmall)
                            Button(onClick={output=PackageCommands.refresh(distro)+"\n"+PackageCommands.upgrade(distro)}){Text("Check and upgrade")}
                        }
                        "AI" -> {
                            Text("AI assistant",style=MaterialTheme.typography.headlineSmall)
                            Dropdown("Provider",provider,listOf("OpenAI","Anthropic")){provider=it}
                            OutlinedTextField(aiPrompt,{aiPrompt=it},label={Text("API key (not saved in this demo form)")},modifier=Modifier.fillMaxWidth())
                            Text("AI API integration scaffold: configure keys in secure settings and implement provider transport before use.")
                        }
                        "VMs" -> {
                            Text("QEMU virtual machines",style=MaterialTheme.typography.headlineSmall)
                            Text("QEMU integration scaffold. VM emulation requires architecture-specific QEMU binaries and storage images.")
                            Button(onClick={output="QEMU binary is not bundled in this source package. See runtime notes in README."}){Text("VM setup notes")}
                        }
                        "Files" -> {
                            Text("App files",style=MaterialTheme.typography.headlineSmall)
                            Button(onClick={output=AppFileOps.list(activity.filesDir).joinToString("\n").ifBlank{"App data directory is empty"})}{Text("Browse app data")}
                        }
                        "Terminal" -> {
                            Text("Shell runner",style=MaterialTheme.typography.headlineSmall)
                            OutlinedTextField(command,{command=it},label={Text("Command")},modifier=Modifier.fillMaxWidth())
                            Button(onClick={output=runner.run(command)}){Text("Run command")}
                            Text("Commands execute in app context. Linux container commands require the container runtime to be provisioned.")
                        }
                        "Settings" -> {
                            Text("Settings",style=MaterialTheme.typography.headlineSmall)
                            Text("Storage: ${activity.filesDir.absolutePath}")
                            Text("Runtime assets, rootfs, terminal and project workspaces are stored in app-private storage.")
                            Button(onClick={output="LinuxForge source version 0.2.0. Runtime readiness and limitations are documented in README."}){Text("About / runtime status")}
                        }
                    }
                    Divider()
                    Text("Output / logs",style=MaterialTheme.typography.titleMedium)
                    Text(output)
                }
            }
        }
    }
}

@Composable private fun Dropdown(label:String,value:String,choices:List<String>,onChange:(String)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box { OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text("$label: $value")}; DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { choices.forEach { DropdownMenuItem(text={Text(it)},onClick={expanded=false;onChange(it)}) } } }
}
