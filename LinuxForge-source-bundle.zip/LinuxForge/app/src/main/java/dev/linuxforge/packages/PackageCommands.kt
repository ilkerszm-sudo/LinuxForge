package dev.linuxforge.packages

enum class DistroFamily { DEBIAN, FEDORA, FREEBSD }
object PackageCommands {
 fun search(f:DistroFamily,q:String)=when(f){DistroFamily.DEBIAN->listOf("apt-cache","search",q);DistroFamily.FEDORA->listOf("dnf","search",q);DistroFamily.FREEBSD->listOf("pkg","search",q)}
 fun install(f:DistroFamily,p:String):List<String>{safe(p);return when(f){DistroFamily.DEBIAN->listOf("apt-get","install","-y",p);DistroFamily.FEDORA->listOf("dnf","install","-y",p);DistroFamily.FREEBSD->listOf("pkg","install","-y",p)}}
 fun remove(f:DistroFamily,p:String):List<String>{safe(p);return when(f){DistroFamily.DEBIAN->listOf("apt-get","remove","-y",p);DistroFamily.FEDORA->listOf("dnf","remove","-y",p);DistroFamily.FREEBSD->listOf("pkg","delete","-y",p)}}
 fun update(f:DistroFamily,upgrade:Boolean)=when(f){DistroFamily.DEBIAN->if(upgrade) listOf("apt-get","upgrade","-y") else listOf("apt-get","update");DistroFamily.FEDORA->if(upgrade) listOf("dnf","upgrade","-y") else listOf("dnf","check-update");DistroFamily.FREEBSD->if(upgrade) listOf("pkg","upgrade","-y") else listOf("pkg","update")}
 private fun safe(s:String){require(s.matches(Regex("[A-Za-z0-9+_.:@/-]{1,128}"))){"Invalid package identifier"}}
}
