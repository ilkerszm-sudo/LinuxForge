package dev.linuxforge.ai
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class ApiKeyVault(context:Context) {
 private val master=MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
 private val prefs=EncryptedSharedPreferences.create(context,"linuxforge_secrets",master,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
 fun put(provider:String,key:String){prefs.edit().putString(provider,key).apply()}
 fun get(provider:String):String?=prefs.getString(provider,null)
 fun remove(provider:String){prefs.edit().remove(provider).apply()}
}
