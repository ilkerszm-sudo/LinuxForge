package dev.linuxforge.engine

import android.content.Context
import java.io.File
import java.net.URL
import java.util.concurrent.Executors

class RootfsManager(private val context:Context) {
    private val executor=Executors.newSingleThreadExecutor()
    private val dir=File(context.filesDir,"containers")
    // Bootstrap archives are downloaded, not shipped, because rootfs images are large and distro licensing/updates require versioned sources.
    fun install(name:String,distro:String,onStatus:(String)->Unit) {
        executor.execute {
            try {
                onStatus("Creating workspace for $distro. Choose a verified rootfs URL in the runtime configuration to proceed.")
                dir.mkdirs(); File(dir,name).mkdirs()
                File(File(dir,name),"INSTALL_NOTES.txt").writeText("Container workspace\nDistro: $distro\n\nNo rootfs archive has been installed. See README for bootstrap steps.\n")
                onStatus("Workspace created. Rootfs installer configuration is not yet integrated with verified distro archive sources.")
            } catch(e:Exception) { onStatus("Install error: ${e.message}") }
        }
    }
}
