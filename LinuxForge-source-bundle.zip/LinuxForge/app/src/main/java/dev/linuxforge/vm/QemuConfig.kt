package dev.linuxforge.vm
data class VmConfig(val name:String,val architecture:String,val memoryMb:Int,val cpuCount:Int,val diskImage:String,val isoImage:String?=null){
 init{require(name.matches(Regex("[A-Za-z0-9_.-]{1,48}")));require(architecture in setOf("x86_64","aarch64","i386","arm"));require(memoryMb in 256..65536);require(cpuCount in 1..16)}
 fun arguments(binary:String)=buildList{add(binary);addAll(listOf("-m",memoryMb.toString(),"-smp",cpuCount.toString(),"-drive","file=$diskImage,format=qcow2,if=virtio"));isoImage?.let{addAll(listOf("-cdrom",it,"-boot","d"))};addAll(listOf("-display","sdl"))}
}
