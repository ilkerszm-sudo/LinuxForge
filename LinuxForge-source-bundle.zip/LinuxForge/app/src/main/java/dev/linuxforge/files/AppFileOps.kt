package dev.linuxforge.files
import java.io.File
object AppFileOps {
 fun list(dir:File):List<File>{require(dir.isDirectory);return dir.listFiles()?.sortedWith(compareBy<File>({!it.isDirectory},{it.name.lowercase()}))?:emptyList()}
 fun createDirectory(parent:File,name:String):File{safe(name);return File(parent,name).apply{check(mkdirs())}}
 fun rename(source:File,name:String):File{safe(name);val target=File(source.parentFile,name);check(!target.exists()&&source.renameTo(target));return target}
 private fun safe(s:String){require(s.matches(Regex("[A-Za-z0-9_. -]{1,80}"))&&s!="."&&s!="..")}
}
