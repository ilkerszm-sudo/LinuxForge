package dev.linuxforge.engine

import android.content.Context
import java.io.File

class ContainerEngine(private val context: Context) {
    private val root = File(context.filesDir,"containers")
    fun start(name:String):String { val dir=File(root,name); if(!dir.exists()) return "Container '$name' is not installed."; return "Rootfs found at ${dir.absolutePath}. Runtime launch requires PRoot executable provisioning (see README)." }
    fun stop(name:String):String = "No managed session process found for '$name'."
    fun remove(name:String):String { val d=File(root,name); if(!d.exists()) return "Not found."; d.deleteRecursively(); return "Removed $name." }
    fun desktopCommand(name:String,de:String):String = "Container '$name': configure X11 socket and install/start $de. Termux:X11 or another compatible X server must be available. See desktop profiles."
}
