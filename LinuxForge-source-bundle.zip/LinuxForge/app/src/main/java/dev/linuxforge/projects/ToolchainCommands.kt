package dev.linuxforge.projects
object ToolchainCommands {
 fun validateProjectName(name:String){require(name.matches(Regex("[A-Za-z][A-Za-z0-9_-]{0,39}")))}
 fun sdkManager(sdkRoot:String,packages:List<String>):List<String>{require(packages.all{it.matches(Regex("[A-Za-z0-9;._-]+"))});return listOf("$sdkRoot/cmdline-tools/latest/bin/sdkmanager",*packages.toTypedArray())}
 fun gradleBuild(task:String="assembleDebug") : List<String>{require(task.matches(Regex("[A-Za-z0-9:._-]+")));return listOf("./gradlew",task,"--no-daemon")}
}
