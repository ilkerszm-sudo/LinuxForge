package dev.linuxforge.desktop

data class DesktopProfile(val label:String,val install:List<String>,val launch:List<String>)
object DesktopProfiles {
 fun forName(name:String)=when(name.lowercase()){
  "xfce"->DesktopProfile("XFCE",listOf("xfce4","xfce4-goodies","dbus-x11"),listOf("dbus-launch","startxfce4"))
  "lxqt"->DesktopProfile("LXQt",listOf("lxqt","qterminal","dbus-x11"),listOf("dbus-launch","startlxqt"))
  "kde"->DesktopProfile("KDE Plasma",listOf("kde-plasma-desktop","konsole","dbus-x11"),listOf("dbus-launch","startplasma-x11"))
  else->error("Unsupported desktop: $name")
 }
 fun x11Environment(display:String=":0")=mapOf("DISPLAY" to display,"PULSE_SERVER" to "127.0.0.1")
}
