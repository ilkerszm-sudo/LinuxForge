# Feature matrix

| Area | Included | Status |
|---|---|---|
| Ten-tab UI | Yes | UI scaffold |
| Container list/workspace/remove | Yes | basic filesystem workspace only |
| Distro rootfs provisioning | partial | no archive unpack or runtime |
| Desktop profiles | Yes | package command suggestions |
| Package actions | Yes | command strings only |
| Updates | Yes | command strings only |
| Project toolchain | Yes | instructions only |
| AI encrypted key vault | Yes | provider transport/chat incomplete |
| QEMU VMs | UI placeholder | runtime not implemented |
| Files | app data listing/helpers | limited |
| Terminal | Android app shell | not Linux-container PTY |
