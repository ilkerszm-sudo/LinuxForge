# Runtime asset directory

Place ABI-specific runtime binaries and their licenses in versioned folders under `app/src/main/jniLibs/<abi>/` only after validating provenance, Android compatibility, checksums and license obligations. No PRoot or QEMU executable is included in this bundle. Avoid downloading arbitrary executable binaries at runtime without signature/checksum verification.
